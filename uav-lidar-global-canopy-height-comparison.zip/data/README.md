# Input data

Place local input rasters in this directory using the default names below, or edit the paths in section 2 of `../multi_product_compare.R`.

| Default file | Required content |
| --- | --- |
| `uav_chm.tif` | High-resolution UAV LiDAR canopy height model |
| `gch_2020.tif` | GCH 2020 canopy-height raster covering the UAV area |
| `gfch_2019.tif` | GFCH 2019 canopy-height raster covering the UAV area |

Heights must be in metres, rasters must have valid coordinate reference systems, and their extents must overlap. Study data are not included in this repository. The `.gitignore` file excludes files placed in this directory so that large or restricted UAV LiDAR data are not accidentally published.

